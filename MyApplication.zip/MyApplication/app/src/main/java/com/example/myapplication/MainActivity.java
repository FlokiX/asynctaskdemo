package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "ЖизненныйЦикл";
    private long startTime;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button button = findViewById(R.id.myButton);

        button.setOnClickListener(v -> {
            Log.i(TAG, "Кнопка была нажата!");
            statusText.setText("Кнопка нажата ✅");
        });

        startTime = System.currentTimeMillis();
        Log.d(TAG, "onCreate вызван");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart (прошло " + (System.currentTimeMillis() - startTime) + " мс от onCreate)");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume (прошло " + (System.currentTimeMillis() - startTime) + " мс от onCreate)");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.w(TAG, "onPause вызван");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.w(TAG, "onStop вызван");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy вызван");
    }
}
