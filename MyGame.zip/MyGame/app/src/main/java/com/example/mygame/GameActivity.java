package com.example.mygame;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    private int secretNumber;
    private EditText numberInput;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // загадываем случайное число от 1 до 100
        secretNumber = new Random().nextInt(100) + 1;

        numberInput = findViewById(R.id.numberInput);
        resultText = findViewById(R.id.resultText);
        Button checkButton = findViewById(R.id.checkButton);

        checkButton.setOnClickListener(v -> {
            String input = numberInput.getText().toString();
            if (input.isEmpty()) {
                resultText.setText("Введите число!");
                return;
            }

            int guess = Integer.parseInt(input);
            if (guess == secretNumber) {
                resultText.setText("Поздравляю! Ты угадал 🎉");
            } else if (guess < secretNumber) {
                resultText.setText("Загаданное число больше ↑");
            } else {
                resultText.setText("Загаданное число меньше ↓");
            }
        });
    }
}
