package com.example.interviewform;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etFullName, etAge;
    private SeekBar sbSalary;
    private TextView tvSalaryValue, tvResult;
    private Button btnSubmit;

    private RadioGroup rgQuestion1, rgQuestion2, rgQuestion3, rgQuestion4, rgQuestion5;
    private CheckBox cbExperience, cbTeamwork, cbBusinessTrips;


    private final int[] correctAnswers = {R.id.rbQ1Option1, R.id.rbQ2Option2,
            R.id.rbQ3Option2, R.id.rbQ4Option2, R.id.rbQ5Option1};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etFullName = findViewById(R.id.etFullName);
        etAge = findViewById(R.id.etAge);
        sbSalary = findViewById(R.id.sbSalary);
        tvSalaryValue = findViewById(R.id.tvSalaryValue);
        tvResult = findViewById(R.id.tvResult);
        btnSubmit = findViewById(R.id.btnSubmit);


        rgQuestion1 = findViewById(R.id.rgQuestion1);
        rgQuestion2 = findViewById(R.id.rgQuestion2);
        rgQuestion3 = findViewById(R.id.rgQuestion3);
        rgQuestion4 = findViewById(R.id.rgQuestion4);
        rgQuestion5 = findViewById(R.id.rgQuestion5);


        cbExperience = findViewById(R.id.cbExperience);
        cbTeamwork = findViewById(R.id.cbTeamwork);
        cbBusinessTrips = findViewById(R.id.cbBusinessTrips);
    }

    private void setupListeners() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                validateForm();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        };

        etFullName.addTextChangedListener(textWatcher);
        etAge.addTextChangedListener(textWatcher);

        sbSalary.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvSalaryValue.setText(progress + " USD");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitForm();
            }
        });
    }

    private void validateForm() {
        String fullName = etFullName.getText().toString().trim();
        String ageText = etAge.getText().toString().trim();

        boolean isFullNameValid = !fullName.isEmpty() && fullName.split(" ").length >= 2;
        boolean isAgeValid = !ageText.isEmpty();

        btnSubmit.setEnabled(isFullNameValid && isAgeValid);
    }

    private void submitForm() {
        // Валидация данных
        if (!validatePersonalData()) {
            return;
        }

        // Расчет баллов
        int score = calculateScore();

        // Проверка результата
        checkResult(score);
    }

    private boolean validatePersonalData() {
        String fullName = etFullName.getText().toString().trim();
        String ageText = etAge.getText().toString().trim();
        int salary = sbSalary.getProgress();

        // Проверка ФИО
        if (fullName.split(" ").length < 2) {
            showError("Пожалуйста, введите полное ФИО (Фамилия Имя Отчество)");
            return false;
        }


        if (ageText.isEmpty()) {
            showError("Пожалуйста, введите возраст");
            return false;
        }

        int age = Integer.parseInt(ageText);
        if (age < 21 || age > 40) {
            showError("Возраст должен быть от 21 до 40 лет");
            return false;
        }


        if (salary < 1000 || salary > 8000) {
            showError("Желаемая зарплата должна быть от 1000 до 8000 USD");
            return false;
        }

        return true;
    }

    private int calculateScore() {
        int score = 0;


        if (rgQuestion1.getCheckedRadioButtonId() == correctAnswers[0]) score += 2;
        if (rgQuestion2.getCheckedRadioButtonId() == correctAnswers[1]) score += 2;
        if (rgQuestion3.getCheckedRadioButtonId() == correctAnswers[2]) score += 2;
        if (rgQuestion4.getCheckedRadioButtonId() == correctAnswers[3]) score += 2;
        if (rgQuestion5.getCheckedRadioButtonId() == correctAnswers[4]) score += 2;


        if (cbExperience.isChecked()) score += 1;
        if (cbTeamwork.isChecked()) score += 1;
        if (cbBusinessTrips.isChecked()) score += 1;

        return score;
    }

    private void checkResult(int score) {
        String fullName = etFullName.getText().toString().trim();

        StringBuilder result = new StringBuilder();
        result.append("Результат для: ").append(fullName).append("\n\n");
        result.append("Набрано баллов: ").append(score).append("/13\n\n");


        if (score >= 8) {
            result.append("Поздравляем Вы прошли тест!\n\n");
            result.append("Контакты компании:\n");
            result.append("📧 hr@itcompany.com\n");
            result.append("📞 +380 (44) 123-45-67\n");
            result.append("🏢 г. Киев, ул. IT, 123");

            tvResult.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));
        } else {
            result.append("К сожалению, вы не прошли тест.\n");
            result.append("Минимальный проходной балл: 8\n");
            result.append("Попробуйте еще раз!");

            tvResult.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
        }

        tvResult.setText(result.toString());
        tvResult.setVisibility(View.VISIBLE);
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}